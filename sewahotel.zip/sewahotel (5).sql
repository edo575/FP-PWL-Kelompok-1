-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Jan 2021 pada 06.57
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sewahotel`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(5) NOT NULL,
  `nama_admin` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id_admin`, `nama_admin`, `username`, `password`) VALUES
(1, 'rynisa', 'rynisa', '45d72883ff110ee497e7d1c1c6daf7cd'),
(2, 'saleh', 'saleh', '8690bca557c4a22fc13928aa31644a08'),
(3, 'adit', 'adit', '486b6c6b267bc61677367eb6b6458764'),
(4, 'edo', 'edo', 'd2d612f72e42577991f4a5936cecbcc0'),
(5, 'fauzi', 'fauzi', '0bd9897bf12294ce35fdc0e21065c8a7'),
(6, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kamar`
--

CREATE TABLE `kamar` (
  `id_kamar` int(5) NOT NULL,
  `id_tipe` int(5) NOT NULL,
  `nama_kamar` varchar(35) NOT NULL,
  `no_kamar` int(5) NOT NULL,
  `tipe_kasur` enum('Single Bed','Twin Bed','Double Bed') NOT NULL,
  `lokasi` enum('Lantai 1','Lantai 2','Lantai 3') NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `tgl_input` date NOT NULL,
  `harga_kamar` int(20) NOT NULL,
  `status_kamar` enum('1','0') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kamar`
--

INSERT INTO `kamar` (`id_kamar`, `id_tipe`, `nama_kamar`, `no_kamar`, `tipe_kasur`, `lokasi`, `gambar`, `tgl_input`, `harga_kamar`, `status_kamar`) VALUES
(17, 1, 'Standar 2', 111, 'Single Bed', 'Lantai 2', 'gambar1609809379.jpg', '2021-01-05', 800000, '0'),
(14, 2, 'Deluxe 2', 102, 'Twin Bed', 'Lantai 2', 'gambar1609809089.jpg', '2021-01-05', 1500000, '1'),
(15, 2, 'Deluxe 3', 103, 'Twin Bed', 'Lantai 1', 'gambar1609809140.jpg', '0000-00-00', 1000000, '1'),
(13, 2, 'Deluxe 1', 101, 'Twin Bed', 'Lantai 3', 'gambar1609809030.jpg', '2021-01-05', 2000000, '1'),
(12, 3, 'Premium Suite 3', 203, 'Double Bed', 'Lantai 1', 'gambar1609808804.jpg', '2021-01-05', 1000000, '1'),
(10, 3, 'Premium Suite 1', 201, 'Double Bed', 'Lantai 3', 'gambar1609808830.jpg', '2021-01-05', 2000000, '0'),
(11, 3, 'Premium Suite 2', 202, 'Double Bed', 'Lantai 2', 'gambar1609808852.jpg', '2021-01-05', 1500000, '1'),
(16, 1, 'Standar 1', 110, 'Single Bed', 'Lantai 3', 'gambar1609809316.jpg', '2021-01-05', 1300000, '1'),
(18, 1, 'Standar 3', 112, 'Single Bed', 'Lantai 1', 'gambar1609809416.jpg', '2021-01-05', 500000, '0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(5) NOT NULL,
  `nama_pelanggan` varchar(45) NOT NULL,
  `gender` enum('Laki-Laki','Perempuan') NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `gender`, `no_telp`, `alamat`, `email`, `password`) VALUES
(1, 'Aditya Ekasakti', 'Laki-Laki', '081233345678', 'Pati, Jawa Tengah', 'adit@gmail.com', '123'),
(2, 'Edo', 'Laki-Laki', '081154876567', 'Magelang', 'edo@gmail.com', '123'),
(3, 'Rynisa', 'Perempuan', '081599123654', 'Jogja', 'sasa@gmail.com', '123'),
(4, 'Saleh', 'Laki-Laki', '089630879456', 'Jauh', 'saleh@gmail.com', '123'),
(5, 'Fauzi', 'Laki-Laki', '08112432123', 'Purbalingga', 'fauzi@gmail.com', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penyewaan`
--

CREATE TABLE `penyewaan` (
  `id_sewa` int(5) NOT NULL,
  `tgl_sewa` datetime NOT NULL,
  `id_pelanggan` int(5) NOT NULL,
  `tgl_cekin` date NOT NULL,
  `tgl_cekout` date NOT NULL,
  `total_extend` double NOT NULL DEFAULT 0,
  `status_bayar` enum('0','1') DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `penyewaan`
--

INSERT INTO `penyewaan` (`id_sewa`, `tgl_sewa`, `id_pelanggan`, `tgl_cekin`, `tgl_cekout`, `total_extend`, `status_bayar`) VALUES
(31, '2021-01-04 09:03:44', 1, '2021-01-06', '2021-01-09', 3000000, '1'),
(32, '2021-01-05 09:03:44', 2, '2021-01-09', '2021-01-16', 0, '0'),
(33, '2021-01-05 09:06:50', 3, '2021-01-05', '2021-01-09', 0, '0'),
(34, '2021-01-05 09:06:50', 5, '2021-01-05', '2021-01-09', 5200000, '1'),
(36, '2021-01-05 09:08:50', 4, '2021-01-05', '2021-01-09', 0, '0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tipekamar`
--

CREATE TABLE `tipekamar` (
  `id_tipe` int(5) NOT NULL,
  `tipe_kamar` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tipekamar`
--

INSERT INTO `tipekamar` (`id_tipe`, `tipe_kamar`) VALUES
(1, 'Standar'),
(2, 'Deluxe'),
(3, 'Premium Suite');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id_sewa` int(11) NOT NULL,
  `tgl_bayar` datetime NOT NULL,
  `id_pelanggan` int(4) NOT NULL,
  `id_kamar` int(4) NOT NULL,
  `tgl_cekin` date NOT NULL,
  `tgl_cekout` date NOT NULL,
  `extend` double NOT NULL,
  `tgl_extend` date NOT NULL,
  `total_extend` double NOT NULL,
  `status_penyewaan` varchar(15) NOT NULL,
  `status_pembayaran` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id_sewa`, `tgl_bayar`, `id_pelanggan`, `id_kamar`, `tgl_cekin`, `tgl_cekout`, `extend`, `tgl_extend`, `total_extend`, `status_penyewaan`, `status_pembayaran`) VALUES
(24, '2020-12-29 05:57:26', 1, 1, '2020-12-29', '2020-12-31', 1, '2020-12-31', 2, '1', '1'),
(26, '2020-12-29 06:04:10', 2, 7, '2020-12-29', '2020-12-31', 1000000, '2020-12-31', 2000000, '1', '1'),
(27, '2020-12-29 06:05:48', 3, 6, '2020-12-25', '2021-01-02', 2000000, '2021-01-02', 16000000, '1', '1'),
(28, '2020-12-29 15:40:28', 10, 5, '2020-12-29', '2021-01-09', 2000000, '2021-01-09', 22000000, '1', '1'),
(29, '2020-12-29 16:00:45', 5, 6, '2020-12-05', '2021-01-09', 1000000, '2021-01-04', 30000000, '1', '1'),
(31, '2021-01-05 02:18:33', 1, 12, '2021-01-06', '2021-01-09', 1000000, '2021-01-09', 3000000, '1', '1'),
(32, '2021-01-05 02:20:16', 2, 17, '2021-01-09', '2021-01-16', 800000, '0000-00-00', 0, '0', '0'),
(33, '2021-01-05 02:21:00', 3, 10, '2021-01-05', '2021-01-09', 2000000, '0000-00-00', 0, '0', '0'),
(34, '2021-01-05 02:22:34', 5, 16, '2021-01-05', '2021-01-09', 1300000, '2021-01-09', 5200000, '1', '1'),
(36, '2021-01-05 02:26:17', 4, 18, '2021-01-05', '2021-01-09', 500000, '0000-00-00', 0, '0', '0');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `kamar`
--
ALTER TABLE `kamar`
  ADD PRIMARY KEY (`id_kamar`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indeks untuk tabel `penyewaan`
--
ALTER TABLE `penyewaan`
  ADD UNIQUE KEY `id_sewa` (`id_sewa`);

--
-- Indeks untuk tabel `tipekamar`
--
ALTER TABLE `tipekamar`
  ADD PRIMARY KEY (`id_tipe`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_sewa`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `kamar`
--
ALTER TABLE `kamar`
  MODIFY `id_kamar` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `penyewaan`
--
ALTER TABLE `penyewaan`
  MODIFY `id_sewa` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT untuk tabel `tipekamar`
--
ALTER TABLE `tipekamar`
  MODIFY `id_tipe` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_sewa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
